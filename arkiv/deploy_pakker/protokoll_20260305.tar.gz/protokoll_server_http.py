#!/usr/bin/env python3
from flask import Flask, request, jsonify
from flask_socketio import SocketIO, emit
import logging
import threading
import time

# Sett opp logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hemmelig'

# Konfigurer SocketIO med CORS for å tillate alle tilkoblinger
socketio = SocketIO(
    app,
    cors_allowed_origins="*",
    logger=True,
    engineio_logger=True,
    ping_timeout=60,
    ping_interval=25
)

def run_protocol(project_name, description):
    """Kjører protokollen i en egen tråd og sender statusoppdateringer"""
    logger.info(f"Starter prosjekt: {project_name} – {description}")
    
    # Send statusoppdateringer via WebSocket
    socketio.emit('status', {'fase': 'SPECS', 'prosent': 10})
    time.sleep(2)
    socketio.emit('status', {'fase': 'SKELETT', 'prosent': 30})
    time.sleep(2)
    socketio.emit('status', {'fase': 'KODE', 'prosent': 60})
    time.sleep(2)
    socketio.emit('status', {'fase': 'VALIDER', 'prosent': 80})
    time.sleep(2)
    socketio.emit('ferdig', {'prosjekt': project_name})

@app.route('/')
def index():
    return jsonify({"status": "running", "message": "Sandkasse Protokoll Server"})

@app.route('/status', methods=['GET'])
def status():
    return jsonify({"status": "ok", "server": "aktiv", "port": 8765})

@app.route('/start', methods=['POST'])
def start_project():
    data = request.get_json()
    project = data.get('project', 'test')
    description = data.get('description', '')
    
    # Start protokollen i en egen tråd
    thread = threading.Thread(target=run_protocol, args=(project, description))
    thread.daemon = True
    thread.start()
    
    return jsonify({"status": "started", "project": project})

@socketio.on('connect')
def handle_connect():
    logger.info('✅ Klient koblet til via WebSocket')
    emit('connection_response', {'data': 'Connected'})

@socketio.on('disconnect')
def handle_disconnect():
    logger.info('❌ Klient koblet fra')

@socketio.on_error()
def handle_error(e):
    logger.error(f'WebSocket-feil: {e}')

if __name__ == '__main__':
    logger.info("Starter Sandkasse Protokoll Server...")
    socketio.run(app, host="0.0.0.0", port=8765, debug=True)
from flask import Flask, request, jsonify
from flask_socketio import SocketIO, emit
import logging
import threading
import time

# Sett opp logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hemmelig'

# Konfigurer SocketIO med CORS for å tillate alle tilkoblinger
socketio = SocketIO(
    app,
    cors_allowed_origins="*",
    logger=True,
    engineio_logger=True,
    ping_timeout=60,
    ping_interval=25
)

def run_protocol(project_name, description):
    """Kjører protokollen i en egen tråd og sender statusoppdateringer"""
    logger.info(f"Starter prosjekt: {project_name} – {description}")
    
    # Send statusoppdateringer via WebSocket
    socketio.emit('status', {'fase': 'SPECS', 'prosent': 10})
    time.sleep(2)
    socketio.emit('status', {'fase': 'SKELETT', 'prosent': 30})
    time.sleep(2)
    socketio.emit('status', {'fase': 'KODE', 'prosent': 60})
    time.sleep(2)
    socketio.emit('status', {'fase': 'VALIDER', 'prosent': 80})
    time.sleep(2)
    socketio.emit('ferdig', {'prosjekt': project_name})

@app.route('/')
def index():
    return jsonify({"status": "running", "message": "Sandkasse Protokoll Server"})

@app.route('/status', methods=['GET'])
def status():
    return jsonify({"status": "ok", "server": "aktiv", "port": 8765})

@app.route('/start', methods=['POST'])
def start_project():
    data = request.get_json()
    project = data.get('project', 'test')
    description = data.get('description', '')
    
    # Start protokollen i en egen tråd
    thread = threading.Thread(target=run_protocol, args=(project, description))
    thread.daemon = True
    thread.start()
    
    return jsonify({"status": "started", "project": project})

@socketio.on('connect')
def handle_connect():
    logger.info('✅ Klient koblet til via WebSocket')
    emit('connection_response', {'data': 'Connected'})

@socketio.on('disconnect')
def handle_disconnect():
    logger.info('❌ Klient koblet fra')

@socketio.on_error()
def handle_error(e):
    logger.error(f'WebSocket-feil: {e}')

if __name__ == '__main__':
    logger.info("Starter Sandkasse Protokoll Server...")
    socketio.run(app, host="0.0.0.0", port=8765, debug=True)
