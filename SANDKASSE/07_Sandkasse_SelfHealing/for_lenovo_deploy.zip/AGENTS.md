﻿# AGENTS.md - Selvhelbredende Systemets Læringsdokument

Dette dokumentet oppdateres automatisk når systemet lærer nye ting.
Hver feil og hver fiks dokumenteres her for å bygge opp systemets "kunnskap".

## System-Prinsipper

1. **Hver feil er en lærdom** - Ingen feil er bortkastet
2. **Automatisk forbedring** - Systemet skal bli bedre over tid
3. **Sikkerhetskopiering** - Alltid backup før endringer
4. **Validering** - Test fikser før de godkjennes

## Vanlige Feil-Mønstre

### IndexError: list index out of range
**Symptom:** Prøver å aksessere liste-element som ikke finnes
**Rotårsak:** Liste er tom eller kortere enn forventet
**Løsning:** 
- Sjekk `len(liste) > 0` før indexering
- Bruk `liste[0] if liste else None`
- Vurder `.get()` eller `.first()` mønstre

### ZeroDivisionError
**Symptom:** Divisjon med null
**Rotårsak:** Ikke-validert input
**Løsning:**
- Sjekk divisor != 0 før operasjon
- Returner default-verdi eller None
- Logg advarsel om uventet input

### KeyError
**Symptom:** Dictionary-nøkkel finnes ikke
**Rotårsak:** Assumert at nøkkel alltid finnes
**Løsning:**
- Bruk `dict.get(key, default)`
- Sjekk `key in dict` før aksess
- Ha fallback-strategier

### AttributeError: 'NoneType'
**Symptom:** Prøver å bruke metode på None
**Rotårsak:** Funksjon returnerte None uventet
**Løsning:**
- Sjekk `if obj is not None:`
- Early return hvis data mangler
- Valider eksterne datakilder

## Konfigurasjon

### Standardverdier
```python
MAX_ATTEMPTS = 3          # Hvor mange ganger prøve å fikse
BACKUP_COUNT = 10         # Hvor mange backups beholde
LOG_LEVEL = "DEBUG"       # Logg-nivå
```

## Suksess-Historier

*Oppdateres automatisk av systemet*

---

**Merk:** Dette dokumentet vokser over tid. Jo mer systemet feiler,
jo mer lærer det, og jo bedre blir dokumentasjonen!
